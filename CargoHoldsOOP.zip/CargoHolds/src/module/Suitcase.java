package module;

import java.util.ArrayList;

public class Suitcase {
    private int maxWeight;
    private int totalWeight;
    private int count;
    private ArrayList<Item> suitcase;

    public Suitcase(int maxWeight) {
        this.maxWeight = maxWeight;
        this.totalWeight = 0;
        this.count = 0;
        this.suitcase = new ArrayList<>();
    }

    public void addItem(Item item) {
        this.suitcase.add(item);
        this.count++;
        this.totalWeight = this.totalWeight + item.getWeight();

        if (this.totalWeight > this.maxWeight) {
            this.suitcase.remove(item);
            this.count--;
            this.totalWeight = this.totalWeight - item.getWeight();
        }
    }

    public int getTotalWeight() {
        return totalWeight;
    }

    public Item getHeaviest() {
        if (this.suitcase.isEmpty()) {
            return null;
        }

        Item returnItem = this.suitcase.get(0);

        for (Item item : this.suitcase) {
            if (returnItem.getWeight() < item.getWeight()) {
                returnItem = item;
            }
        }

        return returnItem;
    }

    @Override
    public String toString() {
        if (count < 2) {
            return count + "item" + "(" + this.totalWeight + "kg" + ")";
        }
        return count + "items" + "(" + this.totalWeight + "kg" + ")";
    }

    public void printItems() {
        String allItems = "";

        for (Item item : this.suitcase) {
            allItems = allItems + item.getName() + "(" + item.getWeight() + "kg" + ")" + "\n";
        }

        System.out.println("The suitcase contains following items:\n" + allItems);

    }
}
