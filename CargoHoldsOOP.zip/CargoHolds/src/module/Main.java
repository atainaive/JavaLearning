package module;

public class Main {

    public static void main(String[] args) {
        Item book = new Item("Book", 1);
        Item phone = new Item("Phone", 2);
        Item brick = new Item("Brick", 4);

        Suitcase suitcase = new Suitcase(10);

        suitcase.addItem(book);
        suitcase.addItem(phone);
        suitcase.addItem(brick);

        suitcase.printItems();
        System.out.println("The total weight: " + suitcase.getTotalWeight() + "kg");

        Item heaviest = suitcase.getHeaviest();
        System.out.println("The heaviest item: " + heaviest);

        Hold hold = new Hold(100);

        hold.addSuitcase(suitcase);
        System.out.println(hold.toString());

        System.out.println("The suitcase in the following hold contains: ");
        hold.printItems(suitcase);
    }
}
