package module;

import java.util.ArrayList;

public class Hold {
    private ArrayList<Suitcase> hold;
    private int count;
    private int totalWeight;
    private int maxWeight;

    public Hold(int maxWeight) {
        this.maxWeight = maxWeight;
        this.hold = new ArrayList<Suitcase>();
        this.count = 0;
        this.totalWeight = 0;
    }

    public void addSuitcase(Suitcase suitcase) {
        this.hold.add(suitcase);
        this.count++;
        this.totalWeight = this.totalWeight + suitcase.getTotalWeight();
    }

    public void printItems(Suitcase suitcase){
        suitcase.printItems();
    }

    @Override
    public String toString() {
        return this.count + " suitcases" + "(" + totalWeight + "kg)";
    }
}
